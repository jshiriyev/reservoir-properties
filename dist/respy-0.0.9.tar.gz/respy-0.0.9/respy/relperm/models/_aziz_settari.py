import numpy as np

class AzizSettari():
    """
    This Model Provides IMBIBITION Relative Permeability MODELS for a THREE-PHASE system.

    """